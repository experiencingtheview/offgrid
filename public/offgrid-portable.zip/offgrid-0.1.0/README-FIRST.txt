OffGrid — start here
===================

You do not need to install Python, Ollama or anything else.

1. Extract this whole zip into a normal folder. Do not run it from inside the
   zip window.

2. Double-click the right launcher:

   Windows   OffGrid.bat
   macOS     OffGrid.command
   Linux     OffGrid.sh

   (On Linux you can also double-click OffGrid.sh; if your file manager asks,
   choose "Run" or "Run in Terminal".)

3. Your browser opens an OffGrid page. Click the big "Set up OffGrid" button
   and leave the black window open while it downloads.

That is the whole setup. The first run needs an internet connection.

What happens on the first run
-----------------------------
OffGrid downloads three things into its own folder:

  * a private Python runtime (about 65 MB), only if your computer does not
    already have a compatible Python;
  * a small local AI engine (about 20 MB);
  * the starter model, Qwen2.5-Coder 3B (about 2 GB).

Nothing is installed system-wide. No account, API key or cloud service is
needed. The model stays in the models folder and works fully offline after
setup. You can move the whole OffGrid folder to another drive or computer.

After that, OffGrid opens its Studio chat page. Use the buttons and text box;
there are no commands to memorise.

If something goes wrong
-----------------------
* Keep the black window open. It contains the full error if the browser page
  cannot explain something.
* If the browser does not open, copy the local address printed in that window
  into your browser.
* If Windows says "Windows protected your PC", click More info, then Run
  anyway. The launchers are not code-signed. If SmartScreen blocks the zip,
  right-click it, choose Properties, tick Unblock, then extract again.
* On macOS, if Gatekeeper refuses it, right-click OffGrid.command, choose Open,
  then Open again. You only need to do that once.
* Interrupted? Click "Try again" or run the launcher again. Completed
  downloads are kept.

If you already use Ollama or LM Studio
--------------------------------------
Start it before OffGrid. Setup finds it automatically and skips the model
download.

Advanced / terminal use
-----------------------
The launch/ scripts are the same entry points used by the top-level launchers.
The single-file app is offgrid.pyz. Useful commands:

  ./OffGrid.sh doctor
  ./OffGrid.sh studio
  ./OffGrid.sh chat

A larger, completely offline USB bundle (portable Python, llama.cpp and the
model) can be built with:

  python3 scripts/setup_usb.py --target /media/USB/offgrid --model 7b

OffGrid never writes to a raw block device. Install to the mounted filesystem,
then unmount it normally.
