/* OffGrid Studio: title and team badge, independent of the chat bundle. */
(() => {
  const TITLE = "OffGrid Studio";

  const keepTitle = () => {
    if (document.title !== TITLE) document.title = TITLE;
  };
  const titleElement = document.querySelector("title");
  if (titleElement && window.MutationObserver) {
    new MutationObserver(keepTitle).observe(titleElement, { childList: true });
  }
  keepTitle();

  const badge = document.getElementById("offgrid-badge");
  const panel = document.getElementById("offgrid-team");
  const toggle = document.getElementById("offgrid-team-toggle");
  const status = document.getElementById("offgrid-status");
  const summary = document.getElementById("offgrid-summary");
  if (!badge || !panel || !toggle) return;

  let loadingState = null;
  let lastPanelMarkup = "";

  const setLoading = (loading) => {
    if (loadingState === loading) return;
    loadingState = loading;
    badge.setAttribute("aria-busy", String(loading));
    if (!summary) return;
    summary.classList.toggle("offgrid-skeleton", loading);
    if (loading) summary.setAttribute("aria-hidden", "true");
    else summary.removeAttribute("aria-hidden");
  };

  const setText = (element, value) => {
    if (element && element.textContent !== value) element.textContent = value;
  };

  const setPanel = (markup) => {
    if (lastPanelMarkup === markup) return;
    lastPanelMarkup = markup;
    panel.innerHTML = markup;
  };

  const setStatus = (text, className) => {
    if (!status) return;
    if (status.textContent !== text) status.textContent = text;
    if (status.className !== className) status.className = className;
  };

  setLoading(true);

  const escape = (value) =>
    String(value == null ? "" : value).replace(/[&<>"']/g, (character) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[character]));

  toggle.addEventListener("click", () => {
    const opening = panel.hasAttribute("hidden");
    if (opening) panel.removeAttribute("hidden");
    else panel.setAttribute("hidden", "");
    toggle.setAttribute("aria-expanded", String(opening));
  });

  const load = async () => {
    try {
      const response = await fetch("/v1/offgrid/info", {
        headers: { Accept: "application/json" },
        cache: "no-store",
      });
      if (!response.ok) throw new Error("HTTP " + response.status);
      const info = await response.json();
      const agents = Array.isArray(info.agents) ? info.agents : [];
      const rows = agents.map((agent) =>
        "<li><b>" + escape(agent.name) + "</b> <span>" + escape(agent.title) + "</span>" +
        (agent.custom ? " <em>custom</em>" : "") + "</li>"
      ).join("");
      setLoading(false);
      setText(summary, (info.model || "auto") + " · " + agents.length + " agents");
      setPanel(
        '<p class="offgrid-workspace">' + escape(info.workspace || "") + "</p>" +
        "<ul>" + rows + "</ul>" +
        (info.warnings && info.warnings.length
          ? '<p class="offgrid-warning">' + escape(info.warnings.join(" ")) + "</p>"
          : "")
      );
      setStatus("ready", "offgrid-status offgrid-ready");
    } catch (error) {
      setLoading(false);
      setText(summary, "start a local model server to chat");
      setPanel(
        '<p class="offgrid-warning">No model answered. Start llama-server, Ollama or LM Studio, ' +
        "then reload this page.</p>"
      );
      setStatus("model offline", "offgrid-status offgrid-offline");
    }
  };

  load();
  window.setInterval(load, 30000);
})();
